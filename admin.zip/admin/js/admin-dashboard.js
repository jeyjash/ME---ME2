/**
 * ME & ME Admin - Dashboard Controller
 * File: admin/js/admin-dashboard.js
 *
 * Responsibilities:
 * - Load product data from the public catalogue
 * - Calculate dashboard statistics
 * - Render recent products
 * - Render low-stock products
 * - Render empty order/activity states
 * - Update dashboard system status
 *
 * NOTE:
 * This is frontend-only for now.
 * Orders, activity and persistent admin data will be connected
 * to the backend/database later.
 */

(function () {
    'use strict';

    const AdminDashboard = {

        products: [],
        collections: [],

        config: {
            productsUrl: '../data/products.json',
            collectionsUrl: '../data/collections.json',

            // Temporary inventory threshold.
            // Change later when inventory is database-driven.
            lowStockThreshold: 5
        },


        /* =========================================================
           INITIALIZATION
           ========================================================= */

        async init() {
            console.log('AdminDashboard: Initializing...');

            this.setSystemStatus('Loading dashboard data...');

            try {
                await this.loadData();

                this.renderStatistics();
                this.renderRecentProducts();
                this.renderLowStockProducts();
                this.renderRecentOrders();
                this.renderRecentActivity();

                this.setSystemStatus('Dashboard ready');

                console.log('AdminDashboard: Ready');
            } catch (error) {
                console.error('AdminDashboard: Failed to initialize', error);

                this.setSystemStatus(
                    'Unable to load dashboard data',
                    'error'
                );

                this.showDashboardError();
            }
        },


        /* =========================================================
           DATA
           ========================================================= */

        async loadData() {
            const [productsResponse, collectionsResponse] =
                await Promise.all([
                    fetch(this.config.productsUrl),
                    fetch(this.config.collectionsUrl)
                ]);

            if (!productsResponse.ok) {
                throw new Error(
                    `Products request failed: ${productsResponse.status}`
                );
            }

            if (!collectionsResponse.ok) {
                throw new Error(
                    `Collections request failed: ${collectionsResponse.status}`
                );
            }

            const productsData = await productsResponse.json();
            const collectionsData = await collectionsResponse.json();

            this.products = Array.isArray(productsData)
                ? productsData
                : Array.isArray(productsData.products)
                    ? productsData.products
                    : [];

            this.collections = Array.isArray(collectionsData)
                ? collectionsData
                : Array.isArray(collectionsData.collections)
                    ? collectionsData.collections
                    : [];

            console.log(
                `AdminDashboard: Loaded ${this.products.length} products`
            );

            console.log(
                `AdminDashboard: Loaded ${this.collections.length} collections`
            );
        },


        /* =========================================================
           STATISTICS
           ========================================================= */

        renderStatistics() {
            const products = this.products;

            const totalProducts = products.length;

            const activeProducts = products.filter(product =>
                this.isActiveProduct(product)
            ).length;

            const newArrivals = products.filter(product =>
                product.isNew === true ||
                product.is_new === true ||
                product.newArrival === true ||
                product.is_new_arrival === true ||
                product.tags?.includes('new')
            ).length;

            const featuredProducts = products.filter(product =>
                product.featured === true ||
                product.isFeatured === true ||
                product.is_featured === true ||
                product.tags?.includes('featured')
            ).length;

            const lowStockProducts = products.filter(product =>
                this.isLowStock(product)
            ).length;

            const outOfStockProducts = products.filter(product =>
                this.isOutOfStock(product)
            ).length;

            this.setText('statTotalProducts', totalProducts);
            this.setText('statActiveProducts', activeProducts);
            this.setText('statNewArrivals', newArrivals);
            this.setText('statFeaturedProducts', featuredProducts);
            this.setText('statCollections', this.collections.length);

            // Orders are not connected to a database yet.
            this.setText('statOrders', '—');

            this.setText('statLowStock', lowStockProducts);
            this.setText('statOutOfStock', outOfStockProducts);

            this.setText(
                'statProductsChange',
                totalProducts === 1
                    ? '1 product in catalogue'
                    : `${totalProducts} products in catalogue`
            );

            this.setText(
                'statActiveProductsChange',
                `${activeProducts} active`
            );

            this.setText(
                'statNewArrivalsChange',
                `${newArrivals} marked as new`
            );

            this.setText(
                'statFeaturedProductsChange',
                `${featuredProducts} featured`
            );

            this.setText(
                'statCollectionsChange',
                `${this.collections.length} published collections`
            );

            this.setText(
                'statOrdersChange',
                'Not connected yet'
            );

            this.setText(
                'statLowStockChange',
                lowStockProducts > 0
                    ? 'Needs attention'
                    : 'Inventory looks healthy'
            );

            this.setText(
                'statOutOfStockChange',
                outOfStockProducts > 0
                    ? 'Needs attention'
                    : 'No products out of stock'
            );
        },


        /* =========================================================
           RECENT PRODUCTS
           ========================================================= */

        renderRecentProducts() {
            const container = document.getElementById('recentProducts');

            if (!container) return;

            if (!this.products.length) {
                this.renderEmptyState(
                    container,
                    'No products yet.',
                    'Add your first product to start building the catalogue.'
                );
                return;
            }

            const products = [...this.products]
                .sort((a, b) => {
                    const dateA = new Date(
                        a.createdAt || a.created_at || 0
                    );

                    const dateB = new Date(
                        b.createdAt || b.created_at || 0
                    );

                    return dateB - dateA;
                })
                .slice(0, 5);

            container.innerHTML = '';

            products.forEach(product => {
                container.appendChild(
                    this.createProductRow(product)
                );
            });
        },


        /* =========================================================
           LOW STOCK
           ========================================================= */

        renderLowStockProducts() {
            const container =
                document.getElementById('lowStockProducts');

            if (!container) return;

            const products = this.products
                .filter(product => this.isLowStock(product))
                .sort((a, b) =>
                    this.getStockQuantity(a) -
                    this.getStockQuantity(b)
                )
                .slice(0, 5);

            if (!products.length) {
                this.renderEmptyState(
                    container,
                    'No low-stock products.',
                    'Your current catalogue does not need stock attention.'
                );
                return;
            }

            container.innerHTML = '';

            products.forEach(product => {
                container.appendChild(
                    this.createInventoryRow(product)
                );
            });
        },


        /* =========================================================
           RECENT ORDERS
           ========================================================= */

        renderRecentOrders() {
            const container =
                document.getElementById('recentOrders');

            if (!container) return;

            /*
             * Orders are intentionally not fabricated.
             * They will come from the backend once the order
             * system is implemented.
             */

            this.renderEmptyState(
                container,
                'Orders are not connected yet.',
                'Orders will appear here once the backend order system is connected.',
                'orders.html'
            );
        },


        /* =========================================================
           RECENT ACTIVITY
           ========================================================= */

        renderRecentActivity() {
            const container =
                document.getElementById('recentActivity');

            if (!container) return;

            /*
             * Activity history requires persistent backend data.
             * Do not manufacture fake activity.
             */

            this.renderEmptyState(
                container,
                'No activity to display.',
                'Activity history will appear here once the admin system is connected.'
            );
        },


        /* =========================================================
           PRODUCT ROW
           ========================================================= */

        createProductRow(product) {
            const row = document.createElement('a');

            row.className = 'dashboard-list-item';

            const slug =
                product.slug ||
                product.id ||
                '';

            row.href =
                `product-editor.html?slug=${encodeURIComponent(slug)}`;

            const image =
                product.image ||
                product.imageUrl ||
                product.image_url ||
                product.images?.[0] ||
                '';

            const name =
                product.name ||
                product.title ||
                'Unnamed product';

            const category =
                product.category ||
                'Uncategorised';

            const price =
                this.formatCurrency(product.price);

            row.innerHTML = `
                <div class="dashboard-list-item__image">
                    ${
                        image
                            ? `<img
                                src="${this.escapeHTML(image)}"
                                alt="${this.escapeHTML(name)}"
                                loading="lazy"
                            >`
                            : `<span aria-hidden="true">◫</span>`
                    }
                </div>

                <div class="dashboard-list-item__content">
                    <strong class="dashboard-list-item__title">
                        ${this.escapeHTML(name)}
                    </strong>

                    <span class="dashboard-list-item__meta">
                        ${this.escapeHTML(category)}
                    </span>
                </div>

                <span class="dashboard-list-item__value">
                    ${price}
                </span>
            `;

            return row;
        },


        /* =========================================================
           INVENTORY ROW
           ========================================================= */

        createInventoryRow(product) {
            const row = document.createElement('a');

            row.className = 'dashboard-list-item dashboard-list-item--inventory';

            const slug =
                product.slug ||
                product.id ||
                '';

            row.href =
                `product-editor.html?slug=${encodeURIComponent(slug)}`;

            const image =
                product.image ||
                product.imageUrl ||
                product.image_url ||
                product.images?.[0] ||
                '';

            const name =
                product.name ||
                product.title ||
                'Unnamed product';

            const quantity =
                this.getStockQuantity(product);

            row.innerHTML = `
                <div class="dashboard-list-item__image">
                    ${
                        image
                            ? `<img
                                src="${this.escapeHTML(image)}"
                                alt="${this.escapeHTML(name)}"
                                loading="lazy"
                            >`
                            : `<span aria-hidden="true">◫</span>`
                    }
                </div>

                <div class="dashboard-list-item__content">
                    <strong class="dashboard-list-item__title">
                        ${this.escapeHTML(name)}
                    </strong>

                    <span class="dashboard-list-item__meta">
                        Stock remaining
                    </span>
                </div>

                <span class="
                    dashboard-list-item__stock
                    ${
                        quantity === 0
                            ? 'dashboard-list-item__stock--danger'
                            : ''
                    }
                ">
                    ${quantity}
                </span>
            `;

            return row;
        },


        /* =========================================================
           PRODUCT STATUS
           ========================================================= */

        isActiveProduct(product) {
            const status =
                String(product.status || '').toLowerCase();

            if (
                status === 'archived' ||
                status === 'draft' ||
                status === 'inactive'
            ) {
                return false;
            }

            if (
                product.active === false ||
                product.isActive === false
            ) {
                return false;
            }

            return true;
        },


        isLowStock(product) {
            const quantity =
                this.getStockQuantity(product);

            return quantity > 0 &&
                quantity <= this.config.lowStockThreshold;
        },


        isOutOfStock(product) {
            return this.getStockQuantity(product) <= 0;
        },


        getStockQuantity(product) {
            const value =
                product.stockQuantity ??
                product.stock_quantity ??
                product.quantity ??
                product.stock;

            const quantity = Number(value);

            return Number.isFinite(quantity)
                ? Math.max(0, quantity)
                : 0;
        },


        /* =========================================================
           EMPTY / ERROR STATES
           ========================================================= */

        renderEmptyState(
            container,
            title,
            description,
            link = null
        ) {
            container.innerHTML = '';

            const wrapper =
                document.createElement('div');

            wrapper.className = 'admin-empty';

            wrapper.innerHTML = `
                <strong>
                    ${this.escapeHTML(title)}
                </strong>

                <p>
                    ${this.escapeHTML(description)}
                </p>

                ${
                    link
                        ? `
                            <a
                                href="${this.escapeHTML(link)}"
                                class="btn btn-secondary btn-sm"
                            >
                                View Orders
                            </a>
                        `
                        : ''
                }
            `;

            container.appendChild(wrapper);
        },


        showDashboardError() {
            const containers = [
                'recentProducts',
                'lowStockProducts'
            ];

            containers.forEach(id => {
                const container =
                    document.getElementById(id);

                if (!container) return;

                container.innerHTML = `
                    <div class="admin-empty">
                        <strong>
                            Unable to load data
                        </strong>

                        <p>
                            Please check that the catalogue data is available.
                        </p>
                    </div>
                `;
            });
        },


        /* =========================================================
           SYSTEM STATUS
           ========================================================= */

        setSystemStatus(message, type = 'success') {
            const status =
                document.getElementById(
                    'dashboardSystemStatus'
                );

            if (status) {
                status.textContent = message;
            }

            const indicator =
                document.querySelector(
                    '.dashboard-system-status'
                );

            if (indicator) {
                indicator.dataset.status = type;
            }
        },


        /* =========================================================
           HELPERS
           ========================================================= */

        setText(id, value) {
            const element =
                document.getElementById(id);

            if (element) {
                element.textContent = value;
            }
        },


        formatCurrency(value) {
            const number = Number(value);

            if (!Number.isFinite(number)) {
                return 'MK 0';
            }

            return new Intl.NumberFormat('en-ZM', {
                style: 'currency',
                currency: 'MWK',
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
            })
                .format(number)
                .replace('MWK', 'MK');
        },


        escapeHTML(value) {
            const element =
                document.createElement('div');

            element.textContent =
                String(value ?? '');

            return element.innerHTML;
        }
    };


    /* =============================================================
       START
       ============================================================= */

    window.AdminDashboard = AdminDashboard;

})();