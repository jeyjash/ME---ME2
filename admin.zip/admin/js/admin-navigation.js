/**
 * ME & ME Admin - Navigation Controller
 * File: admin/js/admin-navigation.js
 * 
 * Responsibilities:
 * - Managing the sidebar state (open/closed)
 * - Handling mobile drawer behavior and overlays
 * - Detecting and marking the active page
 * - Keyboard accessibility (ESC to close)
 */

(function() {
    'use strict';

    const AdminNavigation = {
        // Elements cache
        els: {
            toggle: null,
            sidebar: null,
            overlay: null,
            closeBtn: null,
            navLinks: []
        },

        /**
         * Initialize navigation logic
         */
        init() {
            this.cacheElements();
            this.bindEvents();
            this.setActivePage();
            console.log('AdminNavigation: System initialized');
        },

        /**
         * Cache DOM elements using the required data attributes
         */
        cacheElements() {
            this.els.toggle = document.querySelector('[data-admin-menu-toggle]');
            this.els.sidebar = document.querySelector('[data-admin-sidebar]');
            this.els.overlay = document.querySelector('[data-admin-sidebar-overlay]');
            this.els.closeBtn = document.querySelector('[data-admin-close-sidebar]');
            this.els.navLinks = Array.from(document.querySelectorAll('[data-admin-nav-link]'));
        },

        /**
         * Bind all interaction events
         */
        bindEvents() {
            // Open Sidebar
            if (this.els.toggle) {
                this.els.toggle.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.openSidebar();
                });
            }

            // Close Sidebar via button
            if (this.els.closeBtn) {
                this.els.closeBtn.addEventListener('click', () => {
                    this.closeSidebar();
                });
            }

            // Close Sidebar via overlay
            if (this.els.overlay) {
                this.els.overlay.addEventListener('click', () => {
                    this.closeSidebar();
                });
            }

            // Close Sidebar when a link is clicked (essential for mobile)
            this.els.navLinks.forEach(link => {
                link.addEventListener('click', () => {
                    this.closeSidebar();
                });
            });

            // Global Keyboard support
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && this.isOpen()) {
                    this.closeSidebar();
                }
            });
        },

        /**
         * Set active state based on current window pathname
         */
        setActivePage() {
            const currentPath = window.location.pathname;
            
            this.els.navLinks.forEach(link => {
                const href = link.getAttribute('href');
                
                // Basic check: does the current path match the link's href?
                // Handles both absolute paths and relative filenames
                if (currentPath.includes(href) || (href === '/' && currentPath === '/')) {
                    link.classList.add('admin-nav__link--active');
                    link.setAttribute('aria-current', 'page');
                } else {
                    link.classList.remove('admin-nav__link--active');
                    link.removeAttribute('aria-current');
                }
            });
        },

        /**
         * Opens the sidebar and shows the overlay
         */
        openSidebar() {
            if (!this.els.sidebar) return;

            this.els.sidebar.classList.add('is-open');
            if (this.els.overlay) {
                this.els.overlay.classList.add('is-visible');
            }
            
            // Prevent body scrolling when sidebar is open
            document.body.style.overflow = 'hidden';
            
            // Accessibility: Focus the first link or close button
            setTimeout(() => {
                if (this.els.closeBtn) this.els.closeBtn.focus();
            }, 100);
        },

        /**
         * Closes the sidebar and hides the overlay
         */
        closeSidebar() {
            if (!this.els.sidebar) return;

            this.els.sidebar.classList.remove('is-open');
            if (this.els.overlay) {
                this.els.overlay.classList.remove('is-visible');
            }
            
            // Restore body scrolling
            document.body.style.overflow = '';
        },

        /**
         * Check if sidebar is currently open
         * @returns {boolean}
         */
        isOpen() {
            return this.els.sidebar ? this.els.sidebar.classList.contains('is-open') : false;
        }
    };

    // Expose to global scope so AdminMain.js can initialize it
    window.AdminNavigation = AdminNavigation;

})();