/**
 * ME & ME Admin - Global Controller
 * File: admin/js/admin-main.js
 * 
 * Responsibilities:
 * - UI Orchestration
 * - Navigation logic
 * - Page-specific module initialization
 * - Global UI event listeners
 */

(function() {
    'use strict';

    const AdminMain = {
        /**
         * Initialize the entire Admin environment
         */
        init() {
            console.log('ME & ME Admin: Initializing system...');
            
            this.initNavigation();
            this.initGlobalUI();
            this.initPageModules();
        },

        /**
         * Handle sidebar, mobile drawer, and active link states
         */
        initNavigation() {
            const sidebarToggle = document.querySelector('.admin-sidebar-toggle');
            const sidebarClose = document.querySelector('.admin-sidebar__close');
            const navLinks = document.querySelectorAll('.admin-nav__link');

            // Mobile Toggle Open
            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', () => {
                    document.body.classList.add('sidebar-open');
                });
            }

            // Mobile Toggle Close
            if (sidebarClose) {
                sidebarClose.addEventListener('click', () => {
                    document.body.classList.remove('sidebar-open');
                });
            }

            // Close sidebar when clicking outside (overlay)
            document.addEventListener('click', (e) => {
                if (document.body.classList.contains('sidebar-open')) {
                    // If click is not inside sidebar and not on the toggle button
                    if (!e.target.closest('.admin-sidebar') && !e.target.closest('.admin-sidebar-toggle')) {
                        document.body.classList.remove('sidebar-open');
                    }
                }
            });

            // Set active state based on current URL
            const currentPath = window.location.pathname;
            navLinks.forEach(link => {
                if (link.getAttribute('href') === currentPath || 
                    (currentPath.endsWith('/') && link.getAttribute('href').includes(currentPath.replace(/\/$/, '')))) {
                    link.classList.add('admin-nav__link--active');
                }
            });
        },

        /**
         * Handle global UI elements (Profile dropdowns, Global Search, etc)
         */
        initGlobalUI() {
            const profileToggle = document.querySelector('.admin-profile__toggle');
            const profileMenu = document.querySelector('.admin-profile__menu');

            if (profileToggle && profileMenu) {
                profileToggle.addEventListener('click', (e) => {
                    e.stopPropagation();
                    profileMenu.classList.toggle('is-visible');
                });

                // Close menu when clicking elsewhere
                document.addEventListener('click', () => {
                    profileMenu.classList.remove('is-visible');
                });
            }
        },

        /**
         * Detect current page and initialize relevant business logic
         */
        initPageModules() {
            // Mapping of Page IDs/Selectors to their respective initialization functions
            const pageMap = {
                '#admin-dashboard': this.initDashboard,
                '#admin-products': this.initProducts,
                '#admin-product-editor': this.initProductEditor,
                '#admin-collections': this.initCollections,
                '#admin-lookbook': this.initLookbook,
                '#admin-cms-homepage': this.initHomepageCMS,
                '#admin-cms-about': this.initAboutCMS,
                '#admin-cms-contact': this.initContactCMS,
                '#admin-media': this.initMediaLibrary,
                '#admin-orders': this.initOrders,
                '#admin-settings': this.initSettings,
                '#admin-login-form': this.initLogin
            };

            for (const [selector, initFunc] of Object.entries(pageMap)) {
                if (document.querySelector(selector)) {
                    console.log(`AdminMain: Initializing module for ${selector}`);
                    initFunc.call(this);
                    break; // Only one page module should be active at a time
                }
            }
        },

        /* ==========================================================================
           PAGE-SPECIFIC HOOKS
           These functions act as bridges to dedicated module files.
           Example: this.initProducts() will call functions inside admin-products.js
           ========================================================================== */

        initLogin() {
            // Login logic is primarily handled by admin-auth.js
            // but we can add UI enhancements here if needed.
        },

        initDashboard() {
            if (window.AdminDashboard) window.AdminDashboard.init();
        },

        initProducts() {
            if (window.AdminProducts) window.AdminProducts.init();
        },

        initProductEditor() {
            if (window.AdminProductEditor) window.AdminProductEditor.init();
        },

        initCollections() {
            if (window.AdminCollections) window.AdminCollections.init();
        },

        initLookbook() {
            if (window.AdminLookbook) window.AdminLookbook.init();
        },

        initHomepageCMS() {
            if (window.AdminCMS) window.AdminCMS.initHomepage();
        },

        initAboutCMS() {
            if (window.AdminCMS) window.AdminCMS.initAbout();
        },

        initContactCMS() {
            if (window.AdminCMS) window.AdminCMS.initContact();
        },

        initMediaLibrary() {
            if (window.AdminMedia) window.AdminMedia.init();
        },

        initOrders() {
            if (window.AdminOrders) window.AdminOrders.init();
        },

        initSettings() {
            if (window.AdminSettings) window.AdminSettings.init();
        }
    };

    // Boot the system on DOM load
    document.addEventListener('DOMContentLoaded', () => {
        AdminMain.init();
    });

    // Expose minimal controller for potential external triggers
    window.AdminMain = AdminMain;

})();