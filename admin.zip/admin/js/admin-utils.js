/**
 * ME & ME Admin - Shared Utility Layer
 * File: admin/js/admin-utils.js
 */

(function() {
    'use strict';

    const MeMeAdmin = {
        // --- DOM Selection ---
        /**
         * Query single element
         * @param {string} selector 
         * @returns {HTMLElement|null}
         */
        qs: (selector) => document.querySelector(selector),

        /**
         * Query all elements
         * @param {string} selector 
         * @returns {NodeList}
         */
        qsa: (selector) => document.querySelectorAll(selector),

        // --- Formatting ---
        /**
         * Formats number to MWK Currency
         * @param {number} value 
         * @returns {string} e.g., "MK 85,000"
         */
        formatCurrency: (value) => {
            const number = typeof value === 'string' ? parseFloat(value.replace(/[^0-9.-]+/g, "")) : value;
            if (isNaN(number)) return 'MK 0';
            return new Intl.NumberFormat('en-ZM', {
                style: 'currency',
                currency: 'MWK',
                minimumFractionDigits: 0,
                maximumFractionDigits: 0,
            }).format(number).replace('MWK', 'MK');
        },

        // --- Notifications (Toasts) ---
        /**
         * Shows a temporary toast notification
         * @param {string} message 
         * @param {'success'|'error'|'warning'|'info'} type 
         */
        showToast: (message, type = 'info') => {
            const toast = document.createElement('div');
            toast.className = `admin-toast admin-toast--${type}`;
            toast.textContent = message;

            document.body.appendChild(toast);

            // Remove from DOM after animation
            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(20px)';
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        },

        // --- Modals / Confirmation ---
        /**
         * Generic confirmation dialog
         * @param {string} message - The question to ask
         * @param {Function} callback - Function to run if user confirms
         * @returns {Promise<boolean>}
         */
        confirmAction: (message, callback) => {
            // As a utility fallback, use browser confirm. 
            // In the future, this will be hooked into .admin-modal
            const confirmed = window.confirm(message);
            if (confirmed && typeof callback === 'function') {
                callback();
            }
            return confirmed;
        },

        // --- State Management ---
        /**
         * Toggles loading state on an element
         * @param {HTMLElement} element 
         * @param {boolean} isLoading 
         */
        setLoading: (element, isLoading) => {
            if (!element) return;
            if (isLoading) {
                element.setAttribute('aria-busy', 'true');
                element.disabled = true;
                element.classList.add('is-loading');
            } else {
                element.setAttribute('aria-busy', 'false');
                element.disabled = false;
                element.classList.remove('is-loading');
            }
        },

        /**
         * Sets error message in a specific container
         * @param {HTMLElement} container 
         * @param {string} message 
         */
        setError: (container, message) => {
            if (!container) return;
            container.textContent = message;
            container.classList.add('form-error');
        },

        /**
         * Sets success message in a specific container
         * @param {HTMLElement} container 
         * @param {string} message 
         */
        setSuccess: (container, message) => {
            if (!container) return;
            container.textContent = message;
            container.classList.add('text-success');
        },

        // --- Validation Helpers ---
        validate: {
            required: (val) => val !== null && val !== undefined && val.toString().trim() !== '',
            email: (val) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val),
            url: (val) => {
                try { new URL(val); return true; } 
                catch { return false; }
            },
            positiveNumber: (val) => !isNaN(val) && parseFloat(val) > 0,
            nonNegativeNumber: (val) => !isNaN(val) && parseFloat(val) >= 0,
            slug: (val) => /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(val)
        },

        // --- Functional Utilities ---
        /**
         * Standard debounce function
         * @param {Function} func 
         * @param {number} wait 
         */
        debounce: (func, wait = 300) => {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        },

        /**
         * Converts string to URL-friendly slug
         * @param {string} text 
         * @returns {string}
         */
        slugify: (text) => {
            return text
                .toString()
                .toLowerCase()
                .trim()
                .replace(/\s+/g, '-')     // Replace spaces with -
                .replace(/[^\w-]+/g, '')  // Remove all non-word chars
                .replace(/--+/g, '-');    // Replace multiple - with single -
        },

        /**
         * Sanitizes string to prevent XSS
         * @param {string} str 
         * @returns {string}
         */
        escapeHTML: (str) => {
            const p = document.createElement('p');
            p.textContent = str;
            return p.innerHTML;
        }
    };

    // Expose to global scope
    window.MeMeAdmin = MeMeAdmin;

})();